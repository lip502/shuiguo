前台访问地址：http://localhost:8080/ssm_sgwlxsptxt/index/index.action
	农户：zhangsan		密码：123
	经销商：lisi			密码：123
	
后台访问地址：http://localhost:8080/ssm_sgwlxsptxt/admin/index.action
	用户名：admin		密码：admin